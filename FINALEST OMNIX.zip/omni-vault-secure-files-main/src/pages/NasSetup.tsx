
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { HardDrive, FolderTree, Server, ArrowLeft, Check } from 'lucide-react';
import { NasConfig } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';
import { Header } from '@/components/Header';

const NasSetup = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [stepIndex, setStepIndex] = useState(0);
  const [nasConfig, setNasConfig] = useState<NasConfig>({
    address: '',
    username: '',
    password: '',
    sharedFolder: '',
    isConnected: false
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setNasConfig(prev => ({ ...prev, [name]: value }));
  };

  const handleTestConnection = () => {
    // In a real app, this would make an actual API call to test the NAS connection
    if (!nasConfig.address || !nasConfig.username || !nasConfig.password || !nasConfig.sharedFolder) {
      toast({
        title: "Missing information",
        description: "Please fill in all fields",
        variant: "destructive"
      });
      return;
    }

    toast({
      title: "Connection successful",
      description: "Connected to NAS server successfully."
    });

    // Simulate successful connection
    setNasConfig(prev => ({ ...prev, isConnected: true }));
    setStepIndex(3); // Skip to completion step
  };

  const handleSaveConfig = () => {
    // In a real app, this would save the configuration to local storage or a backend
    localStorage.setItem('nasConfig', JSON.stringify(nasConfig));
    toast({
      title: "Configuration saved",
      description: "Your NAS configuration has been saved."
    });
    navigate('/');
  };

  const setupSteps = [
    {
      title: "NAS Server Information",
      description: "Enter your NAS server connection details",
      icon: <Server className="h-6 w-6" />,
      content: (
        <div className="space-y-4">
          <div className="grid w-full items-center gap-2">
            <Label htmlFor="address">NAS Server Address</Label>
            <Input 
              type="text" 
              id="address"
              name="address"
              placeholder="e.g., 192.168.1.100:5000 or nas.local" 
              value={nasConfig.address}
              onChange={handleInputChange}
            />
          </div>
          <div className="grid w-full items-center gap-2">
            <Label htmlFor="username">Username</Label>
            <Input 
              type="text" 
              id="username" 
              name="username"
              placeholder="NAS username" 
              value={nasConfig.username}
              onChange={handleInputChange}
            />
          </div>
          <div className="grid w-full items-center gap-2">
            <Label htmlFor="password">Password</Label>
            <Input 
              type="password" 
              id="password" 
              name="password"
              placeholder="NAS password" 
              value={nasConfig.password}
              onChange={handleInputChange}
            />
          </div>
        </div>
      )
    },
    {
      title: "Shared Folder Configuration",
      description: "Select the folder on your NAS to use for file storage",
      icon: <FolderTree className="h-6 w-6" />,
      content: (
        <div className="space-y-4">
          <div className="grid w-full items-center gap-2">
            <Label htmlFor="sharedFolder">Shared Folder Path</Label>
            <Input 
              type="text" 
              id="sharedFolder" 
              name="sharedFolder"
              placeholder="e.g., /files/encrypted or shared/documents" 
              value={nasConfig.sharedFolder}
              onChange={handleInputChange}
            />
          </div>
          <Alert>
            <HardDrive className="h-4 w-4" />
            <AlertTitle>Important</AlertTitle>
            <AlertDescription>
              Make sure the shared folder has write permissions for the user you're connecting with.
            </AlertDescription>
          </Alert>
        </div>
      )
    },
    {
      title: "Test Connection",
      description: "Verify your NAS connection",
      icon: <Server className="h-6 w-6" />,
      content: (
        <div className="space-y-4">
          <p className="text-muted-foreground">
            Click the button below to test your NAS connection with the provided details.
          </p>
          <Button onClick={handleTestConnection} className="w-full">
            Test Connection
          </Button>
        </div>
      )
    },
    {
      title: "Setup Complete",
      description: "Your NAS is now configured",
      icon: <Check className="h-6 w-6" />,
      content: (
        <div className="space-y-4">
          <div className="p-4 bg-primary/10 rounded-md text-center">
            <Check className="h-8 w-8 text-primary mx-auto mb-2" />
            <p className="font-medium">NAS connection successful!</p>
            <p className="text-sm text-muted-foreground mt-1">
              Your files will be securely stored on your NAS server.
            </p>
          </div>
          <Button onClick={handleSaveConfig} className="w-full">
            Save Configuration & Return Home
          </Button>
        </div>
      )
    }
  ];

  const currentStep = setupSteps[stepIndex];

  return (
    <div className="min-h-screen flex flex-col">
      <Header onSelectFileCategory={() => {}} selectedCategory="all" />
      
      <main className="flex-1 container py-8">
        <div className="max-w-2xl mx-auto">
          <Button 
            variant="ghost" 
            size="sm" 
            className="mb-4 flex items-center gap-1"
            onClick={() => navigate('/')}
          >
            <ArrowLeft className="h-4 w-4" /> Back to Home
          </Button>
          
          <Card>
            <CardHeader>
              <div className="flex items-center gap-3 mb-2">
                {currentStep.icon}
                <CardTitle>{currentStep.title}</CardTitle>
              </div>
              <CardDescription>{currentStep.description}</CardDescription>
            </CardHeader>
            <CardContent>
              {currentStep.content}
            </CardContent>
            {stepIndex < setupSteps.length - 1 && (
              <CardFooter className="flex justify-between">
                <Button 
                  variant="outline" 
                  onClick={() => stepIndex > 0 && setStepIndex(stepIndex - 1)}
                  disabled={stepIndex === 0}
                >
                  Previous
                </Button>
                <Button 
                  onClick={() => setStepIndex(stepIndex + 1)}
                >
                  Next
                </Button>
              </CardFooter>
            )}
          </Card>
          
          <div className="mt-8 flex justify-center">
            <div className="flex gap-2">
              {setupSteps.map((_, i) => (
                <div 
                  key={i}
                  className={`h-2 w-6 rounded-full ${i <= stepIndex ? 'bg-primary' : 'bg-muted'}`}
                ></div>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default NasSetup;
