
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { EncryptionCard } from '@/components/EncryptionCard';
import { DecryptionCard } from '@/components/DecryptionCard';
import { FileList } from '@/components/FileList';
import { EnhancedPasswordInput } from '@/components/EnhancedPasswordInput';
import { FileItem, DecryptionStatus, FileCategory } from '@/lib/types';
import { getEncryptedFiles, decryptFile, deleteEncryptedFile } from '@/lib/mockApi';
import { downloadFile } from '@/lib/fileUtils';
import { Shield, Download, AlertTriangle, CheckCircle, Loader2, HardDrive, Lock, Upload, History, FileText } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { AuditLogViewer } from '@/components/AuditLogViewer';
import { AlgorithmSelector } from '@/components/AlgorithmSelector';
import { useTheme } from '@/hooks/use-theme';

const Index = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { theme, setTheme } = useTheme();
  const [files, setFiles] = useState<FileItem[]>([]);
  const [selectedFile, setSelectedFile] = useState<FileItem | null>(null);
  const [decryptPassword, setDecryptPassword] = useState('');
  const [decryptionStatus, setDecryptionStatus] = useState<DecryptionStatus>('idle');
  const [decryptDialogOpen, setDecryptDialogOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<FileCategory>('all');
  const [activeTab, setActiveTab] = useState('encrypt');
  
  const loadFiles = async () => {
    setIsLoading(true);
    try {
      const historyFiles = JSON.parse(localStorage.getItem('fileHistory') || '[]');
      setFiles(historyFiles);
    } catch (error) {
      toast({
        title: "Failed to load history",
        description: "Could not load file history. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  useEffect(() => {
    loadFiles();
  }, []);
  
  const handleDecryptFile = (file: FileItem) => {
    setSelectedFile(file);
    setDecryptPassword('');
    setDecryptionStatus('idle');
    setDecryptDialogOpen(true);
  };
  
  const handleDeleteFile = async (fileId: string) => {
    try {
      const deleted = await deleteEncryptedFile(fileId);
      
      if (deleted) {
        setFiles(prevFiles => prevFiles.filter(file => file.id !== fileId));
        toast({
          title: "File removed",
          description: "The file has been removed from history."
        });
      } else {
        throw new Error("Delete operation failed");
      }
    } catch (error) {
      toast({
        title: "Delete failed",
        description: "Could not remove the file. Please try again.",
        variant: "destructive"
      });
    }
  };
  
  const handleDecryptSubmit = async () => {
    if (!selectedFile) return;
    
    setDecryptionStatus('decrypting');
    
    try {
      const encryptedFiles = JSON.parse(localStorage.getItem('encryptedFiles') || '[]');
      
      const fileMatch = encryptedFiles.find((f: any) => f.name === selectedFile.name);
      const passwordMatch = fileMatch?.password === decryptPassword;
      
      await new Promise(resolve => setTimeout(resolve, 500));
      
      if (passwordMatch) {
        const result = await decryptFile(selectedFile, decryptPassword);
        
        if (result.success && result.file) {
          setDecryptionStatus('decrypted');
          
          downloadFile(result.file);
          
          toast({
            title: "Decryption successful",
            description: "Your file has been decrypted and downloaded."
          });
          
          setTimeout(() => {
            setDecryptDialogOpen(false);
            setDecryptionStatus('idle');
            loadFiles(); // Refresh file history
          }, 2000);
        } else {
          setDecryptionStatus('error');
          toast({
            title: "Decryption failed",
            description: result.message || "File corrupt or unrecognized format.",
            variant: "destructive"
          });
        }
      } else {
        setDecryptionStatus('error');
        toast({
          title: "Decryption failed",
          description: "Incorrect password or file not found.",
          variant: "destructive"
        });
      }
    } catch (error) {
      setDecryptionStatus('error');
      toast({
        title: "Decryption error",
        description: "An unexpected error occurred during decryption.",
        variant: "destructive"
      });
    }
  };
  
  const renderDecryptDialogContent = () => {
    if (decryptionStatus === 'decrypting') {
      return (
        <div className="py-6 text-center space-y-4">
          <Loader2 className="h-12 w-12 mx-auto animate-spin text-primary" />
          <div>
            <p className="font-medium">Decrypting your file...</p>
            <p className="text-sm text-muted-foreground">Please wait, this may take a moment</p>
          </div>
        </div>
      );
    }
    
    if (decryptionStatus === 'decrypted') {
      return (
        <div className="py-6 text-center space-y-4">
          <CheckCircle className="h-12 w-12 mx-auto text-green-500" />
          <div>
            <p className="font-medium">File decrypted successfully!</p>
            <p className="text-sm text-muted-foreground">Your file download should begin automatically</p>
          </div>
        </div>
      );
    }
    
    if (decryptionStatus === 'error') {
      return (
        <div className="space-y-4">
          <div className="py-4 text-center">
            <AlertTriangle className="h-12 w-12 mx-auto text-destructive" />
            <p className="font-medium mt-2">Decryption failed</p>
            <p className="text-sm text-muted-foreground">Please check your password and try again</p>
          </div>
          
          <EnhancedPasswordInput
            password={decryptPassword}
            setPassword={setDecryptPassword}
            label="Password"
            placeholder="Enter your decryption password..."
            showGenerator={false}
          />
          
          <div className="flex justify-end">
            <Button onClick={handleDecryptSubmit}>Try Again</Button>
          </div>
        </div>
      );
    }
    
    return (
      <div className="space-y-4">
        <EnhancedPasswordInput
          password={decryptPassword}
          setPassword={setDecryptPassword}
          label="Password"
          placeholder="Enter your decryption password..."
          showGenerator={false}
        />
        
        <div className="flex justify-end">
          <Button onClick={handleDecryptSubmit}>Decrypt File</Button>
        </div>
      </div>
    );
  };

  const filteredFiles = files.filter(file => 
    selectedCategory === 'all' || file.type === selectedCategory
  );
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header onSelectFileCategory={setSelectedCategory} selectedCategory={selectedCategory} />
      
      <div className="container max-w-5xl mx-auto py-8 px-4 flex-1">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <Shield className="h-10 w-10 text-primary mr-2" />
            <h1 className="text-3xl md:text-4xl font-bold">OmniX</h1>
          </div>
          <p className="text-xl text-muted-foreground">Secure file encryption platform</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="md:col-span-1">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lock className="h-5 w-5" /> Security
              </CardTitle>
              <CardDescription>
                Military-grade encryption for your sensitive files
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Choose from 5 powerful encryption algorithms: AES-256, RSA, ChaCha20, Twofish, and Blowfish.
              </p>
            </CardContent>
          </Card>
          
          <Card className="md:col-span-1">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="h-5 w-5" /> Cloud Storage
              </CardTitle>
              <CardDescription>
                Upload encrypted files to your personal NAS
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  Store your encrypted files securely on your NAS server.
                </p>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="w-full"
                  onClick={() => navigate('/nas-files')}
                >
                  Browse NAS Files
                </Button>
              </div>
            </CardContent>
          </Card>
          
          <Card className="md:col-span-1">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <HardDrive className="h-5 w-5" /> NAS Setup
              </CardTitle>
              <CardDescription>
                Configure your NAS for secure file storage
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  Connect your Network Attached Storage for enhanced security.
                </p>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="w-full"
                  onClick={() => navigate('/nas-setup')}
                >
                  Configure NAS
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <Tabs defaultValue="encrypt" value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-8">
            <TabsTrigger value="encrypt">Encrypt File</TabsTrigger>
            <TabsTrigger value="decrypt">Decrypt File</TabsTrigger>
            <TabsTrigger value="history">History</TabsTrigger>
            <TabsTrigger value="audit">Audit Logs</TabsTrigger>
          </TabsList>
          
          <TabsContent value="encrypt" className="space-y-4">
            <EncryptionCard onEncryptionComplete={loadFiles} />
          </TabsContent>
          
          <TabsContent value="decrypt" className="space-y-4">
            <DecryptionCard onDecryptionComplete={loadFiles} />
          </TabsContent>
          
          <TabsContent value="history" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <History className="h-5 w-5" /> File History
                </CardTitle>
                <CardDescription>View your encryption and decryption history</CardDescription>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="py-10 text-center">
                    <Loader2 className="h-8 w-8 mx-auto animate-spin text-primary" />
                    <p className="mt-2 text-muted-foreground">Loading history...</p>
                  </div>
                ) : (
                  <FileList 
                    files={filteredFiles} 
                    onDecrypt={handleDecryptFile}
                    onDelete={handleDeleteFile}
                  />
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="audit" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" /> Audit Logs
                </CardTitle>
                <CardDescription>View detailed encryption and decryption activity</CardDescription>
              </CardHeader>
              <CardContent>
                <AuditLogViewer />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
      
      <Dialog open={decryptDialogOpen} onOpenChange={setDecryptDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Decrypt File</DialogTitle>
            <DialogDescription>
              Enter your password to decrypt and download the file
            </DialogDescription>
          </DialogHeader>
          
          {renderDecryptDialogContent()}
        </DialogContent>
      </Dialog>
      
      <Footer />
    </div>
  );
};

export default Index;
