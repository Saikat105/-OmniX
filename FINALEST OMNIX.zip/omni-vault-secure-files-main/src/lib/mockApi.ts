
import { FileItem, EncryptionResult, DecryptionResult, EncryptionAlgorithm } from './types';
import { logAuditEntry } from './encryptionUtils';

// Optimized delay function to simulate faster API calls
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, Math.min(ms, 50))); // Cap at 50ms for even faster response

// Get encryption speed factor based on algorithm (simulated)
const getAlgorithmSpeedFactor = (algorithm: EncryptionAlgorithm): number => {
  switch (algorithm) {
    case 'ChaCha20': return 0.5; // Fastest
    case 'Blowfish': return 0.7;
    case 'AES-256': return 1.0; // Baseline
    case 'RSA': return 2.5; // Slowest
    case 'Twofish': return 1.2;
    default: return 1.0;
  }
};

// Improved encryption function
export const encryptFile = async (file: File, password: string, algorithm: EncryptionAlgorithm = 'AES-256', compress: boolean = false): Promise<EncryptionResult> => {
  const startTime = performance.now();
  
  // Apply algorithm-specific speed factor to simulate different encryption speeds
  const speedFactor = getAlgorithmSpeedFactor(algorithm);
  await delay(Math.min(file.size / 10000000 * 50 * speedFactor, 100)); // Super fast processing
  
  try {
    // Create a file ID
    const fileId = crypto.randomUUID();
    const originalSize = file.size;
    
    // Simulate compression if enabled
    let finalSize = originalSize;
    if (compress) {
      finalSize = Math.floor(originalSize * 0.8); // Simulate 20% compression
    }
    
    // Create proper filename with _encrypted suffix
    const baseName = file.name.includes('.') 
      ? file.name.substring(0, file.name.lastIndexOf('.')) 
      : file.name;
    const extension = file.name.includes('.') 
      ? file.name.substring(file.name.lastIndexOf('.')) 
      : '';
    const encryptedFileName = `${baseName}_encrypted${extension}.encrypted`;
    
    // Store the original file content for later decryption
    const reader = new FileReader();
    const fileContent = await new Promise<ArrayBuffer>((resolve) => {
      reader.onload = () => resolve(reader.result as ArrayBuffer);
      reader.readAsArrayBuffer(file);
    });
    
    // Store the file info, password, and actual content in localStorage for later decryption
    const encryptedFiles = JSON.parse(localStorage.getItem('encryptedFiles') || '[]');
    const encryptedFileInfo = {
      id: fileId,
      name: encryptedFileName,
      password: password,
      originalName: file.name,
      originalType: file.type,
      size: finalSize,
      originalSize: originalSize,
      algorithm: algorithm,
      compressed: compress,
      encryptedAt: new Date().toISOString(),
      content: Array.from(new Uint8Array(fileContent)) // Store content as array of numbers
    };
    
    localStorage.setItem('encryptedFiles', JSON.stringify([...encryptedFiles, encryptedFileInfo]));
    
    const endTime = performance.now();
    const encryptionTime = endTime - startTime;
    
    // Log the encryption action
    logAuditEntry({
      action: 'encrypt',
      fileName: file.name,
      algorithm: algorithm,
      success: true,
      fileSize: file.size
    });
    
    return {
      success: true,
      message: 'File encrypted successfully',
      fileId: fileId,
      encryptionTime,
      algorithm,
      originalSize,
      encryptedSize: finalSize,
      encryptedFileName
    };
  } catch (error) {
    console.error('Encryption error:', error);
    
    // Log the failed encryption attempt
    logAuditEntry({
      action: 'encrypt',
      fileName: file.name,
      algorithm: algorithm,
      success: false,
      fileSize: file.size
    });
    
    return {
      success: false,
      message: 'An error occurred during encryption'
    };
  }
};

// Improved decryption function
export const decryptFile = async (fileItem: FileItem, password: string): Promise<DecryptionResult> => {
  const startTime = performance.now();
  
  // Get algorithm from file metadata or default to AES-256
  const algorithm = fileItem.algorithm || 'AES-256';
  
  // Apply algorithm-specific speed factor to simulate different decryption speeds
  const speedFactor = getAlgorithmSpeedFactor(algorithm);
  await delay(Math.min(fileItem.size / 10000000 * 50 * speedFactor, 100)); // Super fast processing
  
  try {
    // Get encrypted files from localStorage
    const encryptedFiles = JSON.parse(localStorage.getItem('encryptedFiles') || '[]');
    
    // Find the file with matching name
    const fileInfo = encryptedFiles.find((f: any) => f.name === fileItem.name);
    
    if (!fileInfo) {
      logAuditEntry({
        action: 'decrypt',
        fileName: fileItem.name,
        algorithm: algorithm,
        success: false
      });
      
      return {
        success: false,
        message: 'File not found in encrypted files'
      };
    }
    
    if (fileInfo.password !== password) {
      logAuditEntry({
        action: 'decrypt',
        fileName: fileItem.name,
        algorithm: algorithm,
        success: false
      });
      
      return {
        success: false,
        message: 'Incorrect password'
      };
    }
    
    // Get original name and add _decrypted suffix
    const originalName = fileInfo.originalName || '';
    const baseName = originalName.includes('.') 
      ? originalName.substring(0, originalName.lastIndexOf('.')) 
      : originalName;
    const extension = originalName.includes('.') 
      ? originalName.substring(originalName.lastIndexOf('.')) 
      : '';
    const decryptedFileName = `${baseName}_decrypted${extension}`;
    
    // Get the original file type or default to octet-stream
    const originalType = fileInfo.originalType || 'application/octet-stream';
    
    // Create the proper file content based on the stored content and type
    let fileContent;
    
    if (fileInfo.content) {
      // Convert the stored array back to ArrayBuffer
      const contentArray = new Uint8Array(fileInfo.content);
      fileContent = contentArray.buffer;
    } else {
      // Fallback content generation based on file type
      if (originalType.includes('application/pdf')) {
        // Create a minimal valid PDF file
        fileContent = new Blob(['%PDF-1.5\n1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n3 0 obj\n<< /Type /Page /Parent 2 0 R /Resources << /Font << /F1 4 0 R >> >> /MediaBox [0 0 612 792] /Contents 5 0 R >>\nendobj\n4 0 obj\n<< /Type /Font /Subtype /Type1 /Name /F1 /BaseFont /Helvetica >>\nendobj\n5 0 obj\n<< /Length 68 >>\nstream\nBT\n/F1 12 Tf\n72 712 Td\n(Decrypted PDF document) Tj\nET\nendstream\nendobj\nxref\n0 6\n0000000000 65535 f\n0000000009 00000 n\n0000000058 00000 n\n0000000115 00000 n\n0000000233 00000 n\n0000000309 00000 n\ntrailer\n<<\n/Size 6\n/Root 1 0 R\n>>\nstartxref\n427\n%%EOF'], { type: 'application/pdf' });
      } else if (originalType.includes('text/')) {
        // For text files
        fileContent = new Blob([`This is the decrypted content of ${decryptedFileName}.\nThe file was encrypted using ${algorithm} algorithm.`], { type: originalType });
      } else if (originalType.includes('image/')) {
        // For images, create a placeholder image
        const canvas = document.createElement('canvas');
        canvas.width = 400;
        canvas.height = 300;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.fillStyle = '#f0f0f0';
          ctx.fillRect(0, 0, 400, 300);
          ctx.font = '20px Arial';
          ctx.fillStyle = '#333';
          ctx.textAlign = 'center';
          ctx.fillText(`Decrypted Image: ${decryptedFileName}`, 200, 130);
          ctx.fillText(`Algorithm: ${algorithm}`, 200, 160);
          canvas.toBlob((blob) => {
            if (blob) fileContent = blob;
          }, originalType);
        }
        // Fallback if canvas is not available
        if (!fileContent) {
          fileContent = new Blob(['Decrypted image content'], { type: originalType });
        }
      } else if (originalType.includes('audio/') || originalType.includes('video/')) {
        // For media files
        fileContent = new Blob(['Decrypted media content'], { type: originalType });
      } else {
        // Default for other file types
        fileContent = new Blob([`Decrypted content for ${decryptedFileName}\nAlgorithm used: ${algorithm}`], { type: originalType });
      }
    }
    
    // Create the decrypted file with proper name and type
    const decryptedFile = new File(
      [fileContent], 
      decryptedFileName, 
      { type: originalType, lastModified: new Date().getTime() }
    );
    
    const endTime = performance.now();
    const decryptionTime = endTime - startTime;
    
    logAuditEntry({
      action: 'decrypt',
      fileName: fileItem.name,
      algorithm: algorithm,
      success: true,
      fileSize: fileItem.size
    });
    
    return {
      success: true,
      message: 'File decrypted successfully',
      file: decryptedFile,
      decryptionTime,
      algorithm: fileInfo.algorithm || algorithm
    };
  } catch (error) {
    console.error('Decryption error:', error);
    
    logAuditEntry({
      action: 'decrypt',
      fileName: fileItem.name,
      algorithm: algorithm, 
      success: false
    });
    
    return {
      success: false,
      message: 'An error occurred during decryption'
    };
  }
};

// Mock function to get list of encrypted files
export const getEncryptedFiles = async (): Promise<FileItem[]> => {
  await delay(50); // Even faster response
  
  // Instead of generating mock files, we'll retrieve files from localStorage
  try {
    const historyFiles = JSON.parse(localStorage.getItem('fileHistory') || '[]');
    return historyFiles;
  } catch (error) {
    console.error('Error retrieving encrypted files:', error);
    return [];
  }
};

// Mock function to delete an encrypted file
export const deleteEncryptedFile = async (fileId: string): Promise<boolean> => {
  await delay(50); // Even faster response
  
  try {
    // Remove from history
    const historyFiles = JSON.parse(localStorage.getItem('fileHistory') || '[]');
    const filteredHistory = historyFiles.filter((file: FileItem) => file.id !== fileId);
    localStorage.setItem('fileHistory', JSON.stringify(filteredHistory));
    
    // Remove from encrypted files
    const encryptedFiles = JSON.parse(localStorage.getItem('encryptedFiles') || '[]');
    const filteredEncrypted = encryptedFiles.filter((file: any) => file.id !== fileId);
    localStorage.setItem('encryptedFiles', JSON.stringify(filteredEncrypted));
    
    return true;
  } catch (error) {
    console.error('Error deleting file:', error);
    return false;
  }
};
