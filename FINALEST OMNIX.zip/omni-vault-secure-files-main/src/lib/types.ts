
export type FileType = 
  'document' | 
  'image' | 
  'video' | 
  'audio' | 
  'archive' | 
  'executable' | 
  'system' | 
  'programming' | 
  'security' |
  'unknown';

export type EncryptionStatus = 'idle' | 'encrypting' | 'encrypted' | 'error';
export type DecryptionStatus = 'idle' | 'decrypting' | 'decrypted' | 'error';

export type EncryptionAlgorithm = 
  'AES-256' | 
  'RSA' | 
  'ChaCha20' | 
  'Twofish' | 
  'Blowfish';

export interface EncryptionProfile {
  id: string;
  name: string;
  algorithm: EncryptionAlgorithm;
  compressionEnabled: boolean;
  description?: string;
}

export interface FileItem {
  id: string;
  name: string;
  type: FileType;
  size: number;
  encrypted: boolean;
  lastModified: Date;
  originalType?: string;
  downloadUrl?: string;
  operation?: 'encrypted' | 'decrypted';
  algorithm?: EncryptionAlgorithm;
  encryptionTime?: number;
  originalSize?: number;
}

export interface EncryptionResult {
  success: boolean;
  message: string;
  fileId?: string;
  downloadUrl?: string;
  encryptionTime?: number;
  algorithm?: EncryptionAlgorithm;
  originalSize?: number;
  encryptedSize?: number;
  encryptedFileName?: string;
}

export interface DecryptionResult {
  success: boolean;
  message: string;
  file?: File;
  decryptionTime?: number;
  algorithm?: EncryptionAlgorithm;
}

export interface NasConfig {
  address: string;
  username: string;
  password: string;
  sharedFolder: string;
  isConnected: boolean;
}

export type FileCategory = 'all' | FileType;

export type ThemeMode = 'light' | 'dark';

export interface AuditLogEntry {
  timestamp: string;
  action: 'encrypt' | 'decrypt';
  fileName: string;
  algorithm: EncryptionAlgorithm;
  success: boolean;
  fileSize?: number;
}
