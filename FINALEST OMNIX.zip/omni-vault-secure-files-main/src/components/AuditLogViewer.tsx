
import React, { useState, useEffect } from 'react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import { Download, Trash2, RefreshCw } from 'lucide-react';
import { getAuditLogs } from '@/lib/encryptionUtils';
import { AuditLogEntry } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';

export function AuditLogViewer() {
  const { toast } = useToast();
  const [logs, setLogs] = useState<AuditLogEntry[]>([]);
  
  const loadLogs = () => {
    const auditLogs = getAuditLogs();
    setLogs(auditLogs);
  };
  
  useEffect(() => {
    loadLogs();
  }, []);
  
  const clearLogs = () => {
    try {
      localStorage.setItem('auditLogs', JSON.stringify([]));
      setLogs([]);
      toast({
        title: "Logs cleared",
        description: "All audit logs have been cleared."
      });
    } catch (error) {
      console.error('Error clearing logs:', error);
      toast({
        title: "Error",
        description: "Failed to clear logs",
        variant: "destructive"
      });
    }
  };
  
  const downloadLogs = () => {
    try {
      const logsData = JSON.stringify(logs, null, 2);
      const blob = new Blob([logsData], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `omnix-audit-logs-${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(a);
      a.click();
      URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "Logs exported",
        description: "Audit logs have been exported as JSON"
      });
    } catch (error) {
      console.error('Error exporting logs:', error);
      toast({
        title: "Error",
        description: "Failed to export logs",
        variant: "destructive"
      });
    }
  };
  
  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleString();
  };
  
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-medium">Audit Logs</h3>
        <div className="flex space-x-2">
          <Button variant="outline" size="sm" onClick={loadLogs}>
            <RefreshCw className="h-4 w-4 mr-1" /> Refresh
          </Button>
          <Button variant="outline" size="sm" onClick={downloadLogs}>
            <Download className="h-4 w-4 mr-1" /> Export
          </Button>
          <Button variant="outline" size="sm" onClick={clearLogs}>
            <Trash2 className="h-4 w-4 mr-1" /> Clear
          </Button>
        </div>
      </div>
      
      <ScrollArea className="h-[200px] rounded-md border">
        {logs.length === 0 ? (
          <div className="p-4 text-center text-muted-foreground">
            No logs available
          </div>
        ) : (
          <div className="space-y-1 p-1">
            {logs.map((log, index) => (
              <div 
                key={index} 
                className={`text-xs p-2 rounded ${
                  log.action === 'encrypt' 
                    ? 'bg-blue-500/10 border-l-2 border-blue-500' 
                    : 'bg-green-500/10 border-l-2 border-green-500'
                } ${!log.success ? 'border-destructive bg-destructive/10' : ''}`}
              >
                <div className="flex justify-between">
                  <span className="font-medium">
                    {log.action === 'encrypt' ? 'Encrypted' : 'Decrypted'}: {log.fileName}
                  </span>
                  <span className="text-muted-foreground">
                    {formatTimestamp(log.timestamp)}
                  </span>
                </div>
                <div className="flex justify-between mt-1">
                  <span>
                    Algorithm: <span className="font-medium">{log.algorithm}</span>
                  </span>
                  <span className={log.success ? "text-green-500" : "text-red-500"}>
                    {log.success ? "Success" : "Failed"}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </ScrollArea>
    </div>
  );
}
