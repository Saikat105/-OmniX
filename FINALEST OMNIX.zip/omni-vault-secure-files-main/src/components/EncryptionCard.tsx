
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { EnhancedFileUpload } from '@/components/EnhancedFileUpload';
import { EnhancedPasswordInput } from '@/components/EnhancedPasswordInput';
import { FileTypeIcon } from '@/components/FileTypeIcon';
import { formatFileSize, getFileType, downloadFile } from '@/lib/fileUtils';
import { encryptFile } from '@/lib/mockApi';
import { EncryptionStatus, EncryptionAlgorithm, EncryptionProfile } from '@/lib/types';
import { Lock, Loader2, Download, UploadCloud, Shield } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useNavigate } from 'react-router-dom';
import { AlgorithmSelector } from './AlgorithmSelector';
import { EncryptionSummary } from './EncryptionSummary';
import { ProfileSelector } from './ProfileSelector';
import { defaultProfiles, getRecommendedAlgorithm } from '@/lib/encryptionUtils';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';

interface EncryptionCardProps {
  onEncryptionComplete: () => void;
}

export function EncryptionCard({ onEncryptionComplete }: EncryptionCardProps) {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [encryptedFile, setEncryptedFile] = useState<File | null>(null);
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [status, setStatus] = useState<EncryptionStatus>('idle');
  const [progress, setProgress] = useState(0);
  const [selectedProfile, setSelectedProfile] = useState<EncryptionProfile>(defaultProfiles[0]);
  const [algorithm, setAlgorithm] = useState<EncryptionAlgorithm>('AES-256');
  const [compressionEnabled, setCompressionEnabled] = useState(true);
  const [advancedMode, setAdvancedMode] = useState(false);
  const [encryptionResult, setEncryptionResult] = useState<{
    timeTaken: number;
    originalSize: number;
    finalSize: number;
  } | null>(null);
  const [configTab, setConfigTab] = useState<string>('profile');
  
  const handleFileSelect = (file: File) => {
    setSelectedFile(file);
    setEncryptedFile(null);
    setStatus('idle');
    
    // Set recommended algorithm based on file type
    const recommendedAlgorithm = getRecommendedAlgorithm(getFileType(file));
    setAlgorithm(recommendedAlgorithm);
    
    // Find a profile that matches this algorithm
    const matchingProfile = defaultProfiles.find(p => p.algorithm === recommendedAlgorithm);
    if (matchingProfile) {
      setSelectedProfile(matchingProfile);
      setCompressionEnabled(matchingProfile.compressionEnabled);
    }
  };
  
  const handleProfileChange = (profile: EncryptionProfile) => {
    setSelectedProfile(profile);
    setAlgorithm(profile.algorithm);
    setCompressionEnabled(profile.compressionEnabled);
  };
  
  const handleEncrypt = async () => {
    if (!selectedFile) {
      toast({
        title: "No file selected",
        description: "Please select a file to encrypt.",
        variant: "destructive"
      });
      return;
    }
    
    if (!password) {
      toast({
        title: "No password provided",
        description: "Please enter a password to encrypt your file.",
        variant: "destructive"
      });
      return;
    }
    
    if (password !== confirmPassword) {
      toast({
        title: "Passwords don't match",
        description: "Please make sure both passwords match.",
        variant: "destructive"
      });
      return;
    }
    
    // Start encryption process
    setStatus('encrypting');
    
    // Faster progress updates
    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 95) {
          clearInterval(interval);
          return 95;
        }
        return prev + Math.random() * 15; // Faster progress
      });
    }, 100); // Update more frequently
    
    try {
      const startTime = performance.now();
      const result = await encryptFile(selectedFile, password, algorithm, compressionEnabled);
      const endTime = performance.now();
      
      clearInterval(interval);
      setProgress(100);
      
      if (result.success) {
        // Create the proper encrypted file name
        const baseName = selectedFile.name.includes('.') 
          ? selectedFile.name.substring(0, selectedFile.name.lastIndexOf('.')) 
          : selectedFile.name;
        const extension = selectedFile.name.includes('.') 
          ? selectedFile.name.substring(selectedFile.name.lastIndexOf('.')) 
          : '';
        const encryptedFileName = `${baseName}_encrypted${extension}.encrypted`;
        
        // Create a mock encrypted file with proper name
        const mockEncryptedFile = new File(
          [await selectedFile.arrayBuffer()], 
          encryptedFileName, 
          { type: 'application/octet-stream' }
        );
        
        setEncryptedFile(mockEncryptedFile);
        setStatus('encrypted');
        
        // Set encryption result for summary
        setEncryptionResult({
          timeTaken: result.encryptionTime || (endTime - startTime),
          originalSize: selectedFile.size,
          finalSize: result.encryptedSize || selectedFile.size
        });
        
        // Store encrypted file info in localStorage
        const encryptedFileInfo = {
          id: result.fileId || crypto.randomUUID(),
          name: encryptedFileName,
          password: password,  // Store password for decryption
          originalName: selectedFile.name,
          originalType: selectedFile.type,
          size: result.encryptedSize || selectedFile.size,
          originalSize: selectedFile.size,
          encryptedAt: new Date().toISOString(),
          algorithm: algorithm,
          compressed: compressionEnabled
        };
        
        // Save to localStorage for password-based decryption later
        const existingFiles = JSON.parse(localStorage.getItem('encryptedFiles') || '[]');
        localStorage.setItem('encryptedFiles', JSON.stringify([...existingFiles, encryptedFileInfo]));
        
        // Add to history
        const historyItem = {
          id: result.fileId || crypto.randomUUID(),
          name: encryptedFileName,
          type: getFileType(selectedFile),
          size: result.encryptedSize || mockEncryptedFile.size,
          encrypted: true,
          lastModified: new Date(),
          originalType: selectedFile.type,
          operation: 'encrypted',
          algorithm: algorithm,
          encryptionTime: result.encryptionTime,
          originalSize: selectedFile.size
        };
        
        const history = JSON.parse(localStorage.getItem('fileHistory') || '[]');
        localStorage.setItem('fileHistory', JSON.stringify([...history, historyItem]));
        
        toast({
          title: "Encryption complete",
          description: "Your file has been encrypted successfully.",
        });
        
        onEncryptionComplete();
      } else {
        setStatus('error');
        toast({
          title: "Encryption failed",
          description: result.message,
          variant: "destructive"
        });
      }
    } catch (error) {
      clearInterval(interval);
      setStatus('error');
      toast({
        title: "Encryption error",
        description: "An unexpected error occurred during encryption.",
        variant: "destructive"
      });
    }
  };
  
  const handleDownload = () => {
    if (encryptedFile) {
      downloadFile(encryptedFile);
      toast({
        title: "Download started",
        description: "Your encrypted file download has begun."
      });
    }
  };
  
  const handleUploadToNas = () => {
    if (encryptedFile) {
      // Check if NAS is configured
      const nasConfig = localStorage.getItem('nasConfig');
      
      if (!nasConfig) {
        toast({
          title: "NAS not configured",
          description: "Please set up your NAS connection first.",
          variant: "destructive"
        });
        navigate('/nas-setup');
        return;
      }
      
      toast({
        title: "Uploading to NAS",
        description: "Your encrypted file is being uploaded to your NAS."
      });
      
      // Simulate upload with timeout
      setTimeout(() => {
        toast({
          title: "Upload complete",
          description: "Your encrypted file has been stored on your NAS."
        });
        
        // Reset form after upload
        resetForm();
        onEncryptionComplete();
      }, 2000);
    }
  };
  
  const resetForm = () => {
    setSelectedFile(null);
    setEncryptedFile(null);
    setPassword('');
    setConfirmPassword('');
    setProgress(0);
    setStatus('idle');
    setEncryptionResult(null);
  };
  
  const renderAdvancedOptions = () => {
    return (
      <Card className="mt-4">
        <CardContent className="pt-4">
          <Tabs value={configTab} onValueChange={setConfigTab}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="profile">Profile</TabsTrigger>
              <TabsTrigger value="custom">Advanced</TabsTrigger>
            </TabsList>
            
            <TabsContent value="profile" className="pt-4">
              <ProfileSelector
                selectedProfile={selectedProfile}
                onProfileChange={handleProfileChange}
              />
              
              {selectedProfile && (
                <div className="mt-4 p-3 bg-muted/50 rounded-md text-sm">
                  <p className="font-medium">Profile settings:</p>
                  <div className="mt-1 space-y-1">
                    <p>• Algorithm: <span className="font-medium">{selectedProfile.algorithm}</span></p>
                    <p>• Compression: <span className="font-medium">{selectedProfile.compressionEnabled ? 'Enabled' : 'Disabled'}</span></p>
                    {selectedProfile.description && (
                      <p className="text-muted-foreground text-xs mt-1">{selectedProfile.description}</p>
                    )}
                  </div>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="custom" className="space-y-4 pt-4">
              <AlgorithmSelector 
                selectedAlgorithm={algorithm}
                onChange={setAlgorithm}
              />
              
              <div className="flex items-center space-x-2">
                <Switch
                  id="compression"
                  checked={compressionEnabled}
                  onCheckedChange={setCompressionEnabled}
                />
                <Label htmlFor="compression">Enable compression</Label>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    );
  };
  
  const renderContent = () => {
    if (status === 'encrypting') {
      return (
        <div className="py-6 text-center space-y-4">
          <Loader2 className="h-12 w-12 mx-auto animate-spin text-primary" />
          <div>
            <p className="font-medium">Encrypting your file...</p>
            <p className="text-sm text-muted-foreground">Please wait, this may take a moment</p>
          </div>
          <Progress value={progress} className="w-full" />
        </div>
      );
    }
    
    if (status === 'encrypted') {
      return (
        <div className="space-y-6">
          <div className="py-4 text-center">
            <div className="bg-primary/10 rounded-full p-3 inline-block mx-auto">
              <Shield className="h-8 w-8 mx-auto text-primary" />
            </div>
            <p className="font-medium mt-2">File encrypted successfully!</p>
            <p className="text-sm text-muted-foreground">Your file is now secure</p>
          </div>
          
          {encryptionResult && (
            <EncryptionSummary
              fileName={selectedFile?.name || 'file'}
              algorithm={algorithm}
              timeTaken={encryptionResult.timeTaken}
              originalSize={encryptionResult.originalSize}
              finalSize={encryptionResult.finalSize}
              compressionEnabled={compressionEnabled}
            />
          )}
          
          <Separator />
          
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Button onClick={handleDownload} className="flex items-center gap-2">
              <Download className="h-4 w-4" /> Download Encrypted File
            </Button>
            
            <Button variant="outline" onClick={handleUploadToNas} className="flex items-center gap-2">
              <UploadCloud className="h-4 w-4" /> Upload to NAS
            </Button>
          </div>
          
          <div className="text-center mt-2">
            <Button variant="link" onClick={resetForm}>
              Encrypt another file
            </Button>
          </div>
        </div>
      );
    }
    
    if (selectedFile) {
      return (
        <div className="space-y-6">
          <div className="flex items-center space-x-3 p-3 border rounded-md bg-secondary/50">
            <FileTypeIcon fileType={getFileType(selectedFile)} size={36} className="text-primary" />
            <div>
              <p className="font-medium truncate max-w-[250px]">{selectedFile.name}</p>
              <p className="text-xs text-muted-foreground">{formatFileSize(selectedFile.size)}</p>
            </div>
            <Button variant="ghost" size="sm" className="ml-auto" onClick={resetForm}>
              Change
            </Button>
          </div>
          
          <div className="space-y-4">
            <EnhancedPasswordInput
              password={password}
              setPassword={setPassword}
              label="Encryption Password"
              placeholder="Create a strong password..."
              showGenerator={true}
            />
            
            <EnhancedPasswordInput
              password={confirmPassword}
              setPassword={setConfirmPassword}
              label="Confirm Password"
              placeholder="Confirm your password..."
              showGenerator={false}
            />
          </div>
          
          <div className="flex items-center space-x-2">
            <Switch
              id="advanced-mode"
              checked={advancedMode}
              onCheckedChange={setAdvancedMode}
            />
            <Label htmlFor="advanced-mode">Advanced encryption options</Label>
          </div>
          
          {advancedMode && renderAdvancedOptions()}
        </div>
      );
    }
    
    return <EnhancedFileUpload onFileSelect={handleFileSelect} />;
  };
  
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Encrypt File</CardTitle>
        <CardDescription>
          Secure your files with advanced encryption
        </CardDescription>
      </CardHeader>
      <CardContent>
        {renderContent()}
      </CardContent>
      {selectedFile && status === 'idle' && (
        <CardFooter className="flex justify-end">
          <Button onClick={handleEncrypt}>Encrypt File</Button>
        </CardFooter>
      )}
    </Card>
  );
}
