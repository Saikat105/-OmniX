
import React, { useEffect, useState } from 'react';
import { Instagram } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

interface InstagramProfile {
  username: string;
  url: string;
  imageUrl: string;
}

const instagramProfiles: InstagramProfile[] = [
  { 
    username: 'b4ucko', 
    url: 'https://www.instagram.com/b4ucko',
    imageUrl: 'https://raw.githubusercontent.com/shadcn-ui/ui/main/apps/www/public/avatars/03.png' // More realistic profile image
  },
  { 
    username: 's.a.h_i_l_m', 
    url: 'https://www.instagram.com/s.a.h_i_l_m',
    imageUrl: 'https://raw.githubusercontent.com/shadcn-ui/ui/main/apps/www/public/avatars/05.png'
  },
  { 
    username: 'yuwxxn', 
    url: 'https://www.instagram.com/yuwxxn',
    imageUrl: 'https://raw.githubusercontent.com/shadcn-ui/ui/main/apps/www/public/avatars/01.png'
  },
  { 
    username: 'bhumi_kaaaaaa', 
    url: 'https://www.instagram.com/bhumi_kaaaaaa',
    imageUrl: 'https://raw.githubusercontent.com/shadcn-ui/ui/main/apps/www/public/avatars/02.png'
  },
];

export function Footer() {
  // We're using real profile pictures from shadcn avatars collection
  // In a production app, you would fetch these from Instagram API
  
  return (
    <footer className="mt-20 py-12 border-t">
      <div className="container mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h3 className="text-2xl font-semibold mb-4">OmniX</h3>
            <p className="text-muted-foreground max-w-md">
              Your ultimate solution for secure file encryption and decryption. 
              Protect your personal data with military-grade encryption, accessible anywhere.
            </p>
          </div>
          
          <div className="flex flex-col items-start md:items-end">
            <h4 className="text-lg font-medium mb-4">Follow Our Contributors</h4>
            <div className="flex gap-4">
              <TooltipProvider>
                {instagramProfiles.map((profile) => (
                  <Tooltip key={profile.username}>
                    <TooltipTrigger asChild>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="rounded-full p-0 h-12 w-12 group"
                        onClick={() => window.open(profile.url, '_blank')}
                      >
                        <Avatar className="h-12 w-12 border-2 border-transparent group-hover:border-primary transition-all">
                          <AvatarImage src={profile.imageUrl} />
                          <AvatarFallback className="bg-primary/20">
                            <Instagram className="h-5 w-5" />
                          </AvatarFallback>
                        </Avatar>
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      @{profile.username}
                    </TooltipContent>
                  </Tooltip>
                ))}
              </TooltipProvider>
            </div>
          </div>
        </div>
        
        <div className="mt-8 text-center text-sm text-muted-foreground">
          <p>OmniX - Secure File Encryption Platform</p>
          <p className="mt-1">© 2025 All rights reserved</p>
        </div>
      </div>
    </footer>
  );
}
